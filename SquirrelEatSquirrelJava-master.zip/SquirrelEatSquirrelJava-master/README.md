# Squirrel Eat Squirrel - Java
This is a clone of the pygame Squirrel Eat Squirrel, but made with java! Fun little side project.
Original python pygame here: http://www.pygame.org/project-Squirrel+Eat+Squirrel-1853-.html
